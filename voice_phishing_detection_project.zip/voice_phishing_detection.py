
import os
import librosa
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

# Feature extraction function
def extract_features(audio_path):
    y, sr = librosa.load(audio_path, sr=16000)
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40)
    mel = librosa.feature.melspectrogram(y=y, sr=sr)
    feature = np.concatenate([
        np.mean(mfcc, axis=1),
        np.std(mfcc, axis=1),
        np.mean(mel, axis=1)
    ])
    return feature

# Model Definition
class RawNet(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.gru = nn.GRU(feat_dim, 64, batch_first=True)
        self.attn = nn.Linear(64, 1)
        self.out = nn.Linear(64, 1)  # Binary output

    def forward(self, x):
        gru_out, _ = self.gru(x)
        attn_weights = torch.softmax(self.attn(gru_out).squeeze(-1), dim=1)
        context = (gru_out * attn_weights.unsqueeze(-1)).sum(dim=1)
        out = torch.sigmoid(self.out(context))
        return out

# Loading data
def load_data(data_dir):
    X, y = [], []
    for label in ['real', 'phishing']:
        folder = os.path.join(data_dir, label)
        for file in os.listdir(folder):
            if file.endswith('.wav'):
                feat = extract_features(os.path.join(folder, file))
                X.append(feat)
                y.append(1 if label == 'phishing' else 0)
    return np.stack(X), np.array(y)

# Training function
def train_model(data_dir, epochs=50):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    X, y = load_data(data_dir)
    X_tensor = torch.tensor(X, dtype=torch.float32).unsqueeze(1).to(device)  # batch, seq_len=1, features
    y_tensor = torch.tensor(y, dtype=torch.float32).to(device)

    model = RawNet(feat_dim=X.shape[1]).to(device)
    criterion = nn.BCELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.0001)

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        outputs = model(X_tensor)
        loss = criterion(outputs.squeeze(), y_tensor)
        loss.backward()
        optimizer.step()
        print(f'Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}')

    os.makedirs('checkpoints', exist_ok=True)
    torch.save(model.state_dict(), './checkpoints/best_model.pth')
    print('Training complete and model saved.')

# Evaluation function
def evaluate(audio_path):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    feature = extract_features(audio_path)
    feature_tensor = torch.tensor(feature, dtype=torch.float32).unsqueeze(0).unsqueeze(1).to(device)
    model = RawNet(feat_dim=feature.shape[0]).to(device)
    model.load_state_dict(torch.load('./checkpoints/best_model.pth', map_location=device))
    model.eval()
    with torch.no_grad():
        pred = model(feature_tensor)
        print('Phishing probability:', pred.item())

# Main routine (for quick testing and usage)
if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Voice Phishing Detection')
    parser.add_argument('--mode', choices=['train', 'eval'], required=True, help='train or eval mode')
    parser.add_argument('--data_dir', default='./data', help='Directory for training data')
    parser.add_argument('--audio_path', help='Audio file path for evaluation')
    parser.add_argument('--epochs', type=int, default=50, help='Number of training epochs')

    args = parser.parse_args()

    if args.mode == 'train':
        train_model(args.data_dir, args.epochs)
    elif args.mode == 'eval':
        if args.audio_path is None:
            print('Please provide --audio_path for evaluation mode')
        else:
            evaluate(args.audio_path)

# To run training:
# python voice_phishing_detection.py --mode train --data_dir ./data --epochs 50
# To run evaluation:
# python voice_phishing_detection.py --mode eval --audio_path ./test/sample.wav
